import sys
import json
import boto3
import botocore

def processData(event, context):

    
    return {
        "statusCode": 200,
    }
